import { IntroJs } from "../intro";
export default function onResize(intro: IntroJs): void;
