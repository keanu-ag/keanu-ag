/**
 * To remove all show element(s)
 *
 * @api private
 */
export default function removeShowElement(): void;
