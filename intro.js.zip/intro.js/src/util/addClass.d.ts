/**
 * Append a class to an element
 * @api private
 */
export default function addClass(element: HTMLElement, className: string): void;
