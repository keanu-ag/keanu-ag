/**
 * Appends `element` to `parentElement`
 */
export default function appendChild(parentElement: HTMLElement, element: HTMLElement, animate?: boolean): void;
