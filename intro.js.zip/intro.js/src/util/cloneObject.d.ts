/**
 * Makes a copy of an object
 * @api private
 */
export default function cloneObject<T>(source: T): T;
