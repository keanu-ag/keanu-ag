export default function debounce(func: Function, timeout: number): (...args: any) => void;
