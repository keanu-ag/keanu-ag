/**
 * Find the nearest scrollable parent
 * copied from https://stackoverflow.com/questions/35939886/find-first-scrollable-parent
 */
export default function getScrollParent(element: HTMLElement): HTMLElement;
