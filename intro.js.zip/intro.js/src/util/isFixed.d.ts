/**
 * Checks to see if target element (or parents) position is fixed or not
 *
 * @api private
 */
export default function isFixed(element: HTMLElement): boolean;
