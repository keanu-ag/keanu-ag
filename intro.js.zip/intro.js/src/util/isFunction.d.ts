declare const _default: (x: any) => x is Function;
export default _default;
