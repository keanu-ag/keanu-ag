/**
 * Removes `element` from `parentElement`
 */
export default function removeChild(element: HTMLElement | null, animate?: boolean): void;
