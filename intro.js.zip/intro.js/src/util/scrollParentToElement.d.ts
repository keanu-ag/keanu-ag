/**
 * scroll a scrollable element to a child element
 */
export default function scrollParentToElement(scrollToElement: boolean, targetElement: HTMLElement): void;
