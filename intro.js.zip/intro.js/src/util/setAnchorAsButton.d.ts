/**
 * Setting anchors to behave like buttons
 *
 * @api private
 */
export default function setAnchorAsButton(anchor: HTMLElement): void;
