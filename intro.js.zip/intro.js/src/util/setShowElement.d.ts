/**
 * To set the show element
 * This function set a relative (in most cases) position and changes the z-index
 *
 * @api private
 */
export default function setShowElement(targetElement: HTMLElement): void;
